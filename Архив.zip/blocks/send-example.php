<table>
    <tr>
        <td style='color:#1a202c;'>
            <b>Номер телефона: </b>
        </td>
        <td style='color:#194bfb; font-weight:bold; padding-left:10px;'>test</td>
    </tr>
</table>