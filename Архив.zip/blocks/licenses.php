<div class="licenses-wrapp">
    <div class="head-text-box">
        <p>Licenses</p>
    </div>
    <div class="licenses-block">
        <div class="licenses-box">
            <img src="../img/licens.png" alt="img">
        </div>
        <div class="licenses-box">
        <div class="licenses-box">
            <img src="../img/licens.png" alt="img">
        </div>
        </div>
        <div class="licenses-box">
        <div class="licenses-box">
            <img src="../img/licens.png" alt="img">
        </div>
        </div>
        <div class="licenses-box">
        <div class="licenses-box">
            <img src="../img/licens.png" alt="img">
        </div>
        </div>
    </div>
</div>