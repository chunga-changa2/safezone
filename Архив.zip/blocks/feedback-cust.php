<div class="feedback-cust-wrapp">
    <div class="head-ser-our head-text-box">
        <p>Feedback from our customers</p>
    </div>
    <div class="feedback-cust-blocs">
        <div class="feedback-cust-box">
            <img src="../img/customer1.png" alt="images">
            <p class="name-cust">Adel Mikoyan</p>
            <p class="position-cust">Director of Development</p>
            <p class="name-compani-cust">Сompany: <span>FedEx</span></p>
            <div class="grade-cust">
                <svg width="24" height="24" viewBox="0 0 24 24" class="star-cust">
                    <path d="M12 17.75L5.82796 20.995L7.00696 14.122L2.00696 9.25501L8.90696 8.25501L11.993 2.00201L15.079 8.25501L21.979 9.25501L16.979 14.122L18.158 20.995L12 17.75Z" stroke="#65c240" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            <p class="text-cust">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quod laborum quas sit laudantium id ea eligendi illum voluptates porro atque minus a, repellat non dignissimos culpa nesciunt explicabo sunt dolore praesentium sint hic, delectus aliquam quidem! Accusantium, necessitatibus. Veritatis voluptas autem tempora architecto, nesciunt doloremque aperiam culpa nemo sunt magni aliquid sit, eveniet quae assumenda vel totam magnam voluptatum fugit ad, ullam saepe! Explicabo corporis, natus vero esse sint tempore sit dolores reprehenderit eaque itaque neque iure a, possimus ipsum deleniti error minus laborum, eveniet ratione delectus odio aliquid sequi praesentium ipsam. Pariatur dicta velit, aliquam harum porro recusandae alias?
            </p>
        </div>
        <div class="feedback-cust-box">
        <img src="../img/customer2.png" alt="images">
            <p class="name-cust">Adel Mikoyan</p>
            <p class="position-cust">Director of Development</p>
            <p class="name-compani-cust">Сompany: <span>Google</span></p>
            <div class="grade-cust">
                <svg width="24" height="24" viewBox="0 0 24 24" class="star-cust">
                    <path d="M12 17.75L5.82796 20.995L7.00696 14.122L2.00696 9.25501L8.90696 8.25501L11.993 2.00201L15.079 8.25501L21.979 9.25501L16.979 14.122L18.158 20.995L12 17.75Z" stroke="#65c240" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            <p class="text-cust">
            Cum nihil optio quidem similique maiores. Quasi aliquid velit et officia commodi laboriosam quibusdam eaque sed tempora! Fugit optio vitae quasi sint adipisci iusto, aut, repellendus asperiores commodi quidem libero nisi incidunt rem? Nam corporis quas veritatis maxime eos, dolores facilis explicabo placeat ipsam vitae cupiditate iste ipsum ratione voluptatum a enim! Atque culpa magnam laboriosam voluptatem quis numquam alias explicabo. Delectus itaque harum reiciendis obcaecati, nostrum assumenda ad. Necessitatibus voluptate temporibus voluptatem iusto quod omnis porro quibusdam magnam consequatur.
            </p>
        </div>
        <div class="feedback-cust-box">
        <img src="../img/customer3.png" alt="images">
            <p class="name-cust">Adel Mikoyan</p>
            <p class="position-cust">Director of Development</p>
            <p class="name-compani-cust">Сompany: <span>Yahoo</span></p>
            <div class="grade-cust">
                <svg width="24" height="24" viewBox="0 0 24 24" class="star-cust">
                    <path d="M12 17.75L5.82796 20.995L7.00696 14.122L2.00696 9.25501L8.90696 8.25501L11.993 2.00201L15.079 8.25501L21.979 9.25501L16.979 14.122L18.158 20.995L12 17.75Z" stroke="#65c240" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            <p class="text-cust">
            Perferendis voluptatibus quidem provident nemo aliquam eos consequatur modi, dolore commodi. Distinctio eligendi nihil unde ex voluptates iusto nisi corporis, ipsam eveniet quasi suscipit veritatis repellat temporibus facere commodi tempora officiis cum nam nostrum aperiam! Dolorem odit voluptatibus placeat perspiciatis dolore facere porro quam impedit deleniti magni? Sit ab earum odio velit omnis eaque, recusandae repudiandae pariatur at vitae blanditiis quasi minus, deleniti sint nisi eos. Eos, qui doloribus ducimus numquam architecto suscipit omnis distinctio totam sapiente vitae, voluptatem autem.
            </p>
        </div>
    </div>
</div>