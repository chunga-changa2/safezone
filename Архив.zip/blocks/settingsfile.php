<?php

// Номер телефона
$phonenamber = "+1 929 733 26 33";

// Навигация
$nav = array(
    'Home',
    'Services',
    'About US',
    'Solution',
    'Promo',
    'Contact',
);


// Вторая навигация / Privacy statement Offer for partners Order a call back Report a bug Vacancies Write a review

// Показать или скрыть даное меню
// 1 Показывать
// 0 Не показывать
$navtwovis = 1;

$navtwo = array(
    'Privacy statement',
    'Offer for partners',
    'Order a call',
    'Report a bug',
    'Vacancies',
    'Write a review',
);


// Социальные кнопки в подвале сайта
// 1 Показывать
// 0 Не показывать
$socInstagram = 1;
$socTelegram = 1;
$socFacebook = 1;
$socTwitter = 1;
$socYT = 1;
$socVK = 1;

// Ссылки на соцсети
$linkVK = 'https://vk.com/';
$linkTwitter = 'https://twitter.com/';
$linkFacebook = 'https://www.facebook.com/';
$linkYT = 'https://www.youtube.com/';
$linkInstagram = 'https://www.instagram.com/';
$linkTelegram = 'https://t.me/ChungaChanga03';















// Текущий год
$dated = date("Y");














?>