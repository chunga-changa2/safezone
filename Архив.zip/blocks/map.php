<div class="head-text-box map-box">
    <p>Our office on the map</p>
</div>
<div class="map-wrapp">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3032.068920644105!2d-74.14619758493394!3d40.54006645605361!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24a34d3ba7e69%3A0xa534d7761978d577!2s20%20Perona%20Ln%2C%20Staten%20Island%2C%20NY%2010308!5e0!3m2!1sru!2sus!4v1652663885309!5m2!1sru!2sus" width="100%" height="550"></iframe>
</div>