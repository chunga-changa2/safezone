<div class="bighead">
    <h1>Building Managment Services <br> Maintenance, New Installations & Upgrades</h1>
    <button data-hystmodal="#myModal">Get Free Estimate</button>
    <div class="hidden-box"></div>
</div>
