<div class="lid-box-wrapp">
    <div class="left-lid-box">
        <div class="in-left-lid-box">
            <img src="../img/calback-img.png" alt="images">
            <p class="name-lid-bo">Muhammad Ali</p>
            <p class="online">on line</p>
        </div>
    </div>
    <hr class="vertical-line-lid-box">
    <div class="right-lid-box">
        <p class="head-text-right-lid-box">
        Our manager is ready to answer all your questions
        </p>
        <p class="head-text-right-lid-box-pod">
        send a request by filling out the form and we will call you back
        </p>
        <button data-hystmodal="#myModal">fill the form</button>
    </div>
</div>